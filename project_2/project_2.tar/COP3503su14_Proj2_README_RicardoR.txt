project2 README file

To compile:
input make on the terminal

To run:
input ./project_2

Known to compile with (from g++ -v): 
gcc version 4.6.4 (Ubuntu/Linaro 4.6.4-1ubuntu1~12.04) 

No special resources needed. 
No configuration needed.
Hit ENTER after every command.

KNOWN BUGS:
Crashes when attempting to add a file direlctly on the terminal. i.e. using the [-f]. 